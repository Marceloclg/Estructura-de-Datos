#include "Amigo.h"

Amigo::Amigo() {
    nombre = "";
    edad = 0;
    sexo = ' ';
    estado = ' ';
}

Amigo::Amigo(string nom, int ed, char sx) {
    nombre = nom;
    edad = ed;
    sexo = sx;
    estado = 'A';
}

void Amigo::setAmigo(string nom, int ed, char sx) {
    nombre = nom;
    edad = ed;
    sexo = sx;
    estado = 'A';
}

string Amigo::getNombre() {
    return nombre;
}

int Amigo::getEdad() {
    return edad;
}

char Amigo::getSexo() {
    return sexo;
}

char Amigo::getEstado() {
    return estado;
}

void Amigo::guardarArchivo(ofstream& fsalida) {
    fsalida.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
    fsalida.write(reinterpret_cast<char*>(&edad), sizeof(edad));
    fsalida.write(reinterpret_cast<char*>(&sexo), sizeof(sexo));
    fsalida.write(reinterpret_cast<char*>(&estado), sizeof(estado));
}

bool Amigo::leerArchivo(ifstream& fentrada) {
    bool k = false;
    if (fentrada.is_open()) {
        fentrada.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
        if (!fentrada.eof()) {
            fentrada.read(reinterpret_cast<char*>(&edad), sizeof(edad));
            fentrada.read(reinterpret_cast<char*>(&sexo), sizeof(sexo));
            fentrada.read(reinterpret_cast<char*>(&estado), sizeof(estado));
            k = true;
        }
    }
    return k;
}

bool Amigo::eliminar(fstream& fes, int nroReg) {
    bool k = false;
    if (fes.is_open()) {
        fes.seekg(getTamBytesRegistro() * (nroReg - 1), ios::beg);
        fes.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
        if (!fes.eof()) {
            fes.read(reinterpret_cast<char*>(&edad), sizeof(edad));
            fes.read(reinterpret_cast<char*>(&sexo), sizeof(sexo));
            fes.read(reinterpret_cast<char*>(&estado), sizeof(estado));

            estado = 'E';
            fes.seekp(getTamBytesRegistro() * (nroReg - 1), ios::beg);
            fes.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
            fes.write(reinterpret_cast<char*>(&edad), sizeof(edad));
            fes.write(reinterpret_cast<char*>(&sexo), sizeof(sexo));
            fes.write(reinterpret_cast<char*>(&estado), sizeof(estado));
            k = true;
        }
    }
    return k;
}

bool Amigo::modificar(fstream& fes, int nroReg) {
    bool k = false;
    if (fes.is_open()) {
        string nomAux;
        nomAux = nombre;
        fes.seekg(getTamBytesRegistro() * (nroReg - 1), ios::beg);
        fes.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
        if (!fes.eof()) {
            nombre = nomAux;
            estado = 'A';
            fes.seekp(getTamBytesRegistro() * (nroReg - 1), ios::beg);
            fes.write(reinterpret_cast<char*>(&nombre), sizeof(nombre));
            fes.write(reinterpret_cast<char*>(&edad), sizeof(edad));
            fes.write(reinterpret_cast<char*>(&sexo), sizeof(sexo));
            fes.write(reinterpret_cast<char*>(&estado), sizeof(estado));
            k = true;
        }
    }
    return k;
}

bool Amigo::buscar(ifstream& fentrada, int nroReg) {
    bool k = false;
    if (fentrada.is_open()) {
        fentrada.seekg(getTamBytesRegistro() * (nroReg - 1), ios::beg);
        fentrada.read(reinterpret_cast<char*>(&nombre), sizeof(nombre));
        fentrada.read(reinterpret_cast<char*>(&edad), sizeof(edad));
        fentrada.read(reinterpret_cast<char*>(&sexo), sizeof(sexo));
        fentrada.read(reinterpret_cast<char*>(&estado), sizeof(estado));
        if (!fentrada.eof()) {
            k = true;
        }
    }
    return k;
}

int Amigo::getTamBytesRegistro() {
    return sizeof(nombre) + sizeof(edad) + sizeof(sexo) + sizeof(estado);
}

