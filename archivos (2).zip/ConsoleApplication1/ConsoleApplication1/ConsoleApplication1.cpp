#include <iostream>
#include <fstream>
#include <conio.h>
#include "ABMamigo.h"

using namespace std;

int main() {
    ABMamigo* amig = new ABMamigo("amigOO.dat");
    amig->adicionarNuevo();
    amig->listar();
    //amig->buscarReg();
    //amig->eliminarReg();
    //amig->modificarReg();
    //amig->listar();
    getch();
    return 0;
}
